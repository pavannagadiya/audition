<script src="<?= RES_URL; ?>client/js/jquery-1.11.1.min.js"></script>
<script src="<?= RES_URL; ?>newClient/lib/jquery/jquery.min.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/venobox/venobox.min.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/knob/jquery.knob.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/wow/wow.min.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/parallax/parallax.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/easing/easing.min.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/nivo-slider/js/jquery.nivo.slider.js" type="text/javascript"></script>
  <script src="<?= RES_URL; ?>newClient/lib/appear/jquery.appear.js"></script>
  <script src="<?= RES_URL; ?>newClient/lib/isotope/isotope.pkgd.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?= RES_URL; ?>newClient/contactform/contactform.js"></script>

  <script src="<?= RES_URL; ?>newClient/js/main.js"></script>

<script src="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.js"></script>
